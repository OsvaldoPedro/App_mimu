import{p as r}from"./index-Cfpa_GRb.js";var a=r();export{a as r};
