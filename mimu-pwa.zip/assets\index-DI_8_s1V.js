import{q as r}from"./index-DF-eGY4G.js";var a=r();export{a as r};
