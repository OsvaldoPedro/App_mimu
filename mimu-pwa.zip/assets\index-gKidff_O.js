import{q as r}from"./index-CWramZud.js";var a=r();export{a as r};
