import{q as r}from"./index-Ot_Zq-bw.js";var a=r();export{a as r};
