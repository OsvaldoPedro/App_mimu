import{p as r}from"./index-CB_MzM9h.js";var a=r();export{a as r};
