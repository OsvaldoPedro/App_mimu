import{q as r}from"./index-CdjF2s62.js";var a=r();export{a as r};
