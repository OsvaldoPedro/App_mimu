import{p as r}from"./index-BmCF8GMR.js";var a=r();export{a as r};
