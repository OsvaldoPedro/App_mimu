import{q as r}from"./index-b_jnCdDy.js";var a=r();export{a as r};
