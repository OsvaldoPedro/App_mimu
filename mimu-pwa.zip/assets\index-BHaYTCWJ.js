import{q as r}from"./index-CN_1_FF3.js";var a=r();export{a as r};
