import{p as r}from"./index-ZHbopQ3M.js";var a=r();export{a as r};
