import{q as r}from"./index-CpUhSZMW.js";var a=r();export{a as r};
