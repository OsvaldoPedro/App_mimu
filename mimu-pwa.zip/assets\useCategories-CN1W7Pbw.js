import{o as r}from"./index-ZHbopQ3M.js";function g(t=!1){const{categories:e,loading:i}=r();return i?{categories:[],loading:!0}:{categories:t?e:e.filter(o=>o.isActive),loading:!1}}export{g as u};
