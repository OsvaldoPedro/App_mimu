import{d as o}from"./index-CdjF2s62.js";function g(t=!1){const{categories:e,loading:i}=o();return i?{categories:[],loading:!0}:{categories:t?e:e.filter(r=>r.isActive),loading:!1}}export{g as u};
