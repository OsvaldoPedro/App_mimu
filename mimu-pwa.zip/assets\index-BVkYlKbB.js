import{q as r}from"./index-MhQYncKy.js";var a=r();export{a as r};
