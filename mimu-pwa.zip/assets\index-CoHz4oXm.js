import{p as r}from"./index-MlM4t4ot.js";var a=r();export{a as r};
