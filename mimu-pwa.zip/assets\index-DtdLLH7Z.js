import{q as r}from"./index-d20VHFPy.js";var a=r();export{a as r};
