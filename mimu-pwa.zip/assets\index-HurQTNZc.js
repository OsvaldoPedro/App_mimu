import{q as r}from"./index-C8QlMjLU.js";var a=r();export{a as r};
