import{q as r}from"./index-Bqu8AmWw.js";var a=r();export{a as r};
