import{p as r}from"./index-DKs-IBRb.js";var a=r();export{a as r};
